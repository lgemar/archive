.. automodule :: nose.selector
   :members: