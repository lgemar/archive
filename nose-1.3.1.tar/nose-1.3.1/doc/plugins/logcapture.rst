Logcapture: capture logging during tests
========================================

.. autoplugin :: nose.plugins.logcapture