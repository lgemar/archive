Deprecated: mark tests as deprecated
====================================

.. autoplugin :: nose.plugins.deprecated
