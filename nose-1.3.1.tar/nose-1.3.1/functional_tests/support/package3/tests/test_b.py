import b

def test_b():
    b.b()
