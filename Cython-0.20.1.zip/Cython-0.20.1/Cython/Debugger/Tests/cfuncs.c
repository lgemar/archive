void
some_c_function(void)
{
    int a, b, c;

    a = 1;
    b = 2;
}
